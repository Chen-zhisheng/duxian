<?php
if($_G['cache']['plugin']['duxian_sslts']['kg'] == 0){
    die('<h1 style="color:red;font-weight:bold;">����ѱ��رգ����� ��̨>Ӧ��>���>ʵʱ������>����>�Ƿ������ �п����������</h1>');
}
@header('Content-Type: text/html; charset=gbk');
error_reporting(0);

$aurl = "source/plugin/duxian_sslts/";//�����URL��ַ
$curl = "plugin.php?id=duxian_sslts:index";//�������ҳ��ַ

$siname = $_G['cache']['plugin']['duxian_sslts']['name'];
$sname = "����ϵͳ";
$version = "2.0";

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
?>

<?php include ('common/header.htm');//����ҳ��html�ļ� ?>
    <br><br><br>
    <section id="chat" class="about">
      <div class="container">

        <div class="row">
          <div class="col-lg-6">
            <iframe src="<?php echo $aurl; ?>liuyanban/liuyan.txt" width="600" height="680" id="txt1"></iframe>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 content">
            <h3><?php echo $siname; ?></h3>
            <p class="fst-italic" style="color:red;font-weight:bold;">
              ���棺<?php echo $_G['cache']['plugin']['duxian_sslts']['annou']; ?>
            </p>
            <button onclick="javascript:refreshFrame();">ˢ����Ϣ</button>
            <button onclick="downloadEvt('<?php echo $aurl; ?>liuyanban/liuyan.txt')">������Ϣ��¼</button>
            <br><br>
            <form action="<?php echo $aurl; ?>liuyan.php" method="get" accept-charset="gbk"  _charset="gbk">
            <label>
                <p>������������������</p>
            <input type="text" name= "lname" required="required" autocomplete="off" maxLength="15" value="<?php echo $_G['member'][username];?>"></label><br><br>
            <p>��������������Ҫ���Ե����ݣ�</p>
            <textarea type="text" name= "ltext" required="required" cols="40" maxLength="500" autocomplete="off"></textarea>
            <br><br><br>
            <input class="button001" type="submit" value="�ύ����" name="">
            </form>
          </div>
          </div>
        </div>

      </div>
    </section>
<script type="text/javascript">
    function refreshFrame(){
        document.getElementById('txt1').contentWindow.location.reload(true);
    }
</script>
<script type="text/javascript">
    var c=0;
    function showLogin()
    {
    	alert(c++);
    }
    setInterval("refreshFrame()","10000");
</script>
<?php include ('common/ad.htm');//����ҳ��html�ļ� ?>
<?php include ('common/footer.htm');//����ҳ��html�ļ� ?>

<?php
    $time = time();
    
    if($_GET["ltext"] != null){
        file_put_contents($aurl."liuyanban/liuyan.txt", date('[Y��m��d�� H��i��s��]',$time).$_GET["lname"]."��".$_GET["ltext"].PHP_EOL, FILE_APPEND);
    }
    if($_SERVER['PHP_SELF'] == "/source/plugin/duxian_tianjie/liuyan.php"){
        echo "<script>window.location.href='".'http://'.$_SERVER['HTTP_HOST']."/plugin.php?id=duxian_sslts:chat';</script>";
    }
?>
  <script type="text/javascript">

    function downloadEvt(url, fileName = '���Լ�¼<?php echo date('[Ymd]',$time); ?>') {
      const el = document.createElement('a');
      el.style.display = 'none';
      el.setAttribute('target', '_blank');
      fileName && el.setAttribute('download', fileName);
      el.href = url;
      console.log(el);
      document.body.appendChild(el);
      el.click();
      document.body.removeChild(el);
    }
  </script>