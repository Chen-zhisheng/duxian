//执行键盘按键命令
function keyDown(e){ 
 var keycode = 0;
 //IE浏览器
 if(CheckBrowserIsIE()){
  keycode = event.keyCode;
 }else{
 //火狐浏览器
 keycode = e.which;
 }
 if (keycode == 13 ) //回车键是13
 {
  //document.getElementById("login").click();
  document.getElementById("loginform").submit();
 }
}
//判断访问者的浏览器是否是IE
function CheckBrowserIsIE(){
 var result = false;
 var browser = navigator.appName;
 if(browser == "Microsoft Internet Explorer"){
  result = true;
 }
 return result;
}