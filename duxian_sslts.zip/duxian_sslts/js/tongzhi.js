function tongzhi1(){
  // 先检查浏览器是否支持
  if (!("Notification" in window)) {
    alert("This browser does not support desktop notification");
  }

  // 检查用户是否同意接受通知
  else if (Notification.permission === "granted") {
    // If it's okay let's create a notification
    var notification = new Notification("成功开始下载，文件较大，可能需要较长的时间！");
  }

  // 否则我们需要向用户获取权限
  else if (Notification.permission !== 'denied') {
    Notification.requestPermission(function (permission){
      // 如果用户同意，就可以向他们发送通知
      if (permission === "granted") {
        var notification = new Notification("成功开始下载，文件较大，可能需要较长的时间！");
      }
    });
  }
}